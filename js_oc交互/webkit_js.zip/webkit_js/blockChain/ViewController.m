//
//  ViewController.m
//  blockChain
//
//  Created by foscom on 16/7/27.
//  Copyright © 2016年 zengjia. All rights reserved.
//

#import "ViewController.h"
#import "quikeHeader.h"
#import "YYDispatchQueuePool.h"
#import "ViewcController.h"
@interface testModel : NSObject

@property(nonatomic,strong)NSString *name;
@property(nonatomic,assign)NSInteger age;

@end

@implementation testModel




@end

@interface ViewController ()

@property(nonatomic,strong)NSString *names;
@property(nonatomic,strong)dispatch_queue_t queues;
@property(nonatomic,strong)NSThread *cutrn;


@end

@implementation ViewController


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    ViewcController *vc = [[ViewcController alloc] init];
    
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    self.study().run();
//
//    self.play(@"name",@"xiaoming");
    // 局部变量
    
    NSLog(@"16jinzhi = %d,%d,%d,%d",1<<0,1<<1,1<<2,1<<3);
    
    
    int i = 0;
    void(^testblock)(NSString *name) = ^(NSString *name){
//        static int c= 0; // 静态变量
        NSLog(@"i = %d",i);
        
//        self.names = name;
//        a=3;
//        int aa = 0;
        int b = 3;

        
       
        
    };
    
    // 用到了局部变量或者属性而且没有强指针指向都是栈block
    
    // 没强指针指向，也没用外界变量都是全局block
    
//    testblock(@"xiaohua");
    NSLog(@"%@",^(NSString *name){
        NSLog(@"%@",self.names);
    });
    
    // 有强指针 而且没使用全局变量,用到局部变量或者属性 就是堆block
    
    // 用到了全局变量 或者静态变量 或者没用外界变量  就是全局block
    NSLog(@"%@",testblock);
    
    NSLog(@"%@",self.names);
    
    NSDictionary *dic = @{@"a":@"3",@"b":@"4"};
    
    testModel *model = [[testModel alloc] init];
    model.name = @"小名";
    model.age = 10;
    CFShow((__bridge CFTypeRef)model);
   if( CFStringHasPrefix((__bridge CFTypeRef)@"abcde", (__bridge CFTypeRef)@"abf"))
   {
       NSLog(@"yes");
   }
    
    NSLog(@"%@",dic);
    /*
    NSLog(@"1");
    dispatch_sync(dispatch_get_main_queue(), ^{
        
       
        NSLog(@"2");
    });
    NSLog(@"3");
    */
    
    /*
    NSLog(@"11");
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
       
        dispatch_sync(dispatch_get_main_queue(), ^{
            
            NSLog(@"22");

        });
        
        NSLog(@"33");

    });
    
    NSLog(@"44");

    */
    CALayer *latyer = [[CALayer alloc] init];

    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 50, 100, 100)];
    
    btn.backgroundColor = [UIColor yellowColor];
    
    [btn addTartgetBlock:^(UIButton * obj) {
        NSLog(@"play actions");
        if (obj.selected ) {
            obj.backgroundColor =[UIColor cyanColor];
            latyer.frame = CGRectMake(100, 100, 100, 100);
            
        }else
        {
            obj.backgroundColor = [UIColor redColor];
            latyer.frame = CGRectMake(100, 200, 100, 100);

        }
        
    }];
    
    [self.view addSubview:btn];
    [self.view addTapGestureActionWithBlck:^(UIGestureRecognizer *Gesture) {
       CGPoint point = [Gesture locationInView:self.view];
       NSLog(@"%f,%f",point.x,point.y);
   }];

    
    
    latyer.frame = CGRectMake(20, 100, 100, 200);
    latyer.backgroundColor = [UIColor clearColor].CGColor;
    
    latyer.cornerRadius = 10;
    latyer.borderWidth = 1;
    latyer.borderColor = [UIColor blueColor].CGColor;
    
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(0, 30)];
    [path addLineToPoint:CGPointMake(100, 30)];
    CAShapeLayer *layersss = [[CAShapeLayer alloc] init];
    layersss.strokeColor = [UIColor redColor].CGColor;
    layersss.fillColor =[ UIColor greenColor].CGColor;
    layersss.path = path.CGPath;
    [latyer addSublayer:layersss];
    
    [self.view.layer addSublayer:latyer];
    
    
    
    
//    UIWebView *web = [[UIWebView alloc] initWithFrame:self.view.bounds];
//    
//    NSURLRequest *reqoust = [NSURLRequest requestWithURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"test222" ofType:@"html"]]];
//    
//    [web loadRequest:reqoust];
//    
//    [self.view addSubview:web];
    
    
}



// 全局变量

- (ViewController* (^)())study
{
    return ^(){
        NSLog(@"study---");
        return self;
    };
    
}
- (ViewController* (^)())run
{
    return ^{
        NSLog(@"run----");
        return self;
    };
    
}

- (ViewController *(^)(NSString*,NSString*))play
{
    return ^(NSString *str,NSString *str2){
    
        NSLog(@"str = %@ name = %@",str,str2);
        return self;
    };
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
