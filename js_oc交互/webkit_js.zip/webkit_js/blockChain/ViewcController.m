//
//  ViewcController.m
//  blockChain
//
//  Created by foscom on 16/9/5.
//  Copyright © 2016年 zengjia. All rights reserved.
//

#import "ViewcController.h"
#import <WebKit/WebKit.h>

@interface ViewcController ()<WKUIDelegate,WKScriptMessageHandler>
@property(nonatomic,strong)WKWebView *webkitview;
@end

@implementation ViewcController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    config.preferences = [[WKPreferences alloc] init];
    config.preferences.minimumFontSize = 20;
    config.preferences.javaScriptEnabled = YES;
    config.preferences.javaScriptCanOpenWindowsAutomatically = NO;
    
//    config.processPool = [[WKProcessPool alloc] init];
    config.userContentController = [[WKUserContentController alloc] init];
    [config.userContentController addScriptMessageHandler:self name:@"demoModel"];
  /*
    配合在 js 中使用下面代码
    window.webkit.messageHandlers.demoModel.postMessage({body:'the mess is need'});
   */
    
    self.webkitview = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
//    self.webkitview.navigationDelegate = self;
    self.webkitview.UIDelegate = self;
    [self.view addSubview:self.webkitview];
    
    
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"index" withExtension:@"html"];
//    [self.webkitview loadRequest:[NSURLRequest requestWithURL:url]];
    
    [self.webkitview loadHTMLString:[NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil] baseURL:url];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.webkitview evaluateJavaScript:@"\
         document.getElementById('testdemo').innerHTML = 'ios 中 webkit 执行了js 代码 ';" completionHandler:^(id _Nullable obj, NSError * _Nullable error) {
             
             // 指向javascript 代码
             NSLog(@"error = %@,obj =%@ ",error,obj);
             
             
         }];

        
    });
    
    
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message
{
    if ([message.name isEqualToString:@"demoModel"]) {
        NSLog(@"argument = %@ ",message.body);
    }
}

- (void)webViewDidClose:(WKWebView *)webView
{
    NSLog(@"%s",__func__);
}
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler
{
    NSLog(@"need alert  = %@",message);
    
    completionHandler();
    
    
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler
{
    NSLog(@"need confirm = %@",message);
    completionHandler(0);

}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler
{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
