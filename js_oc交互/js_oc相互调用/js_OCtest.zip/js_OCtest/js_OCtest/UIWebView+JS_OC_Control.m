//
//  UIWebView+JS_OC_Control.m
//  js_OCtest
//
//  Created by foscom on 16/9/7.
//  Copyright © 2016年 zengjia. All rights reserved.
//

#import "UIWebView+JS_OC_Control.h"

@implementation UIWebView (JS_OC_Control)

- (void)changeMarkWith:(NSString *)oldmarkId andNew:(NSString *)newMark
{
    NSString *controlStr = [NSString stringWithFormat:@"var custom=document.getElementById('%@');custom.innerHTML='%@'",oldmarkId,newMark];
    [self stringByEvaluatingJavaScriptFromString:controlStr];
}
@end
