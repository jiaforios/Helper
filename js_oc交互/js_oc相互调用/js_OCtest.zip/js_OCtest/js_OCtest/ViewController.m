//
//  ViewController.m
//  js_OCtest
//
//  Created by foscom on 16/9/7.
//  Copyright © 2016年 zengjia. All rights reserved.
//

#import "ViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "UIWebView+JS_OC_Control.h"
@interface ViewController ()<UIWebViewDelegate>
{
    UIWebView *webviews;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    
    webviews = [[UIWebView alloc] initWithFrame:CGRectMake(10, 100, 300, 300)];
    
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"index" withExtension:@"html"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [webviews loadRequest:request];

    webviews.delegate = self;
    [self.view addSubview:webviews];
    
    
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    static BOOL once = NO;
    once = !once;
    if (once) {
       [webviews stringByEvaluatingJavaScriptFromString:@"oc_jsAction()"];
    
    }else
    {
       [webviews stringByEvaluatingJavaScriptFromString:@"oc_jsAction2('xiaoming',50)"];
    }
}



- (void)menthod1
{
    NSLog(@"js无参数传递");
}

- (void)methodWithArgument:(NSArray *)argument
{
    NSLog(@"从js传递来的参数 %@",argument);
}

- (void)method3
{
    NSLog(@"响应 js 的confirm 事件");
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSLog(@"开始响应请求时触发");
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    NSLog(@"开始加载网页");
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [webView changeMarkWith:@"testdemo" andNew:@"Hello World"];
    
    JSContext *jscontext = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    
    jscontext[@"test1"] = ^(){
        [self menthod1];
    };
    
    jscontext[@"test2"] = ^(){
        NSArray *dataArr = [JSContext currentArguments];
        [self methodWithArgument:dataArr];
    };
    
    jscontext[@"test3"] = ^(){
    
        [self method3];
    };

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
