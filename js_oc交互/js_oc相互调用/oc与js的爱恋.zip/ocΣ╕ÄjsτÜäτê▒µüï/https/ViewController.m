//
//  ViewController.m
//  https
//
//  Created by 涛程 on 16/3/24.
//  Copyright © 2016年 涛程. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UINavigationBarDelegate,UIActionSheetDelegate,UIWebViewDelegate>
{
//    UILabel *name;
    UILabel *password;
    UIButton *bt;
    UIWebView *webview;
    NSString * _html;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    NSString *ds = [NSString stringWithFormat:@"fsf"];
    bt = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 50, 50)];
    bt.backgroundColor = [UIColor orangeColor];
    [bt addTarget:self action:@selector(pushbaidu) forControlEvents:UIControlEventTouchDown];
    
    webview = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    webview.backgroundColor = [UIColor yellowColor];
    webview.delegate =self;
    [self.view addSubview:webview];
    [self.view addSubview:bt];
   //加载网络
//    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://www.taobao.com"]];
//    加载本地
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"index" withExtension:@"html"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [webview loadRequest:request];

    
    //创建两个原生button,演示调用js方法
    UIButton * btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn1.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height/2, 200, 50);
    btn1.backgroundColor = [UIColor blackColor];
    [btn1 setTitle:@"OC调用无参JS" forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(function1) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];
    UIButton * btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn2.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height/2+100, 200, 50);
    btn2.backgroundColor = [UIColor blackColor];
    [btn2 setTitle:@"OC调用JS(传参)" forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(function2) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
    
    
    
}
- (void)pushbaidu{
    NSLog( @"ni shi zhu ma ");
 
}
#pragma 供JS调用的方法
-(void)menthod1{
    NSLog(@"JS调用了无参数OC方法1111");
    
}
-(void)menthod2:(NSString *)str1 and:(NSString *)str2{
    
    NSLog(@"%@%@",str1,str2);
}
#pragma OC调用JS方法
-(void)function1{
    [webview stringByEvaluatingJavaScriptFromString:@"aaa()"];
}
-(void)function2{
    NSString * name = @"pheromone";
    NSInteger num = 520;
    NSString *str = [NSString stringWithFormat:@"bbb('%@','%ld');",name,num];
    [webview stringByEvaluatingJavaScriptFromString:str];
}

#pragma UIWebViewDelegate方法
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSLog(@"开始响应请求时触发");
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    NSLog(@"开始加载网页");
}
//      UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView{
     NSLog(@"网页加载完毕");
    /*
     <p class="myimg">
     <img src="http://p1.ifengimg.com/a/2016_24/be65927e27de090_size57_w530_h318.jpg" width=​"312" height=​"312" alt >
     </p>
 －－－－－－－－1.获取id为‘myimg’的p标签，然后删除－－－－－－－－－－－－－－－－－
//     */
//    NSString *str1 = @"var p = document.getElementById('myimg');";
//    NSString *str2 = @"p.remove();";
//    [webView stringByEvaluatingJavaScriptFromString:str1];
//    [webView stringByEvaluatingJavaScriptFromString:str2];
    
//－－－－－－－2.更改 修改<li class = "shouye">首页</li>列表标签的内容－－－－－－－－－－－－－－－－－
    NSString *str3 = @"var zzz = document.getElementsByClassName('shouye')[0];""zzz.innerHTML = '你是猪吗？？';";
    [webView stringByEvaluatingJavaScriptFromString:str3];
    
//－－－－－－－3.插入 图片－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－
    NSString *str4 = @"var img = document.createElement('player');"
    "img.src = 'http://yuntv.letv.com/player/live/blive.js';"
    "img.width = '320';"
    "img.height = '180';"
    "img = new CloudLivePlayer();"
    "img.init =({activityId:'A2016080300000in'});"
    "document.body.appendChild(img);";
    /*
     前面
     "var first=document.body.firstChild;"
     "document.body.insertBefore(img,first);"
     */
    [webView stringByEvaluatingJavaScriptFromString:str4];
    // 拼接一个脚本语言中的 自动定位代码
    /*
     <div id="player" style="width:100%;height:450px;">
     <script type="text/javascript" charset="utf-8" src="http://yuntv.letv.com/player/live/blive.js"></script>
     <script>
     var player = new CloudLivePlayer();
     player.init({activityId:"A2016080300000in"});
     </script>
     </div>
     
     <div id="player" style="width:100%;height:450px;">
     <script type="text/javascript" charset="utf-8" src="http://yuntv.letv.com/player/live/blive.js"></script>
     <script>
     var player = new CloudLivePlayer();
     player.init({activityId:"A2016080900000hj"});
     </script>
     </div>

     */
//－－－－－－－4.js中给标签添加相印事件－－－－－－－－－－－－－－－－－－－
    NSString *str5 = @"var baidu = document.getElementsByTagName('a')[0];"
//    NSString *str5 = @"var baidu = document.getElementById('dsd');"
    "baidu.innerHTML = '你是猪a ？？';"
    "baidu.onclick = function(){alert('点我点我点我')};";
    [webView stringByEvaluatingJavaScriptFromString:str5];
    
//－－－－－－－5js调用oc-－－－－－－－－－－－－－－－－－－－－－－－－－－－
    //JSContext * context;
    //获取js的运行环境
    _context=[webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    //html调用无参数OC
    _context[@"test1"] = ^(){
        [self menthod1];
    };
    //html调用OC(传参数过来)
    _context[@"test2"] = ^(){
        NSArray * args = [JSContext currentArguments];//传过来的参数
        //        for (id  obj in args) {
        //            NSLog(@"html传过来的参数%@",obj);
        //        }
        NSString * name = args[0];
        NSString * str = args[1];
        [self menthod2:name and:str];
    };

}

@end
