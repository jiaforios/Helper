//
//  LAndRRequest.h
//  XFDNavTest
//
//  Created by lwk on 15/11/30.
//  Copyright © 2015年 lwk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking/AFNetworking.h"

@class LAndRRequest;
//协议方法：通知视图控制器请求的结果
@protocol ZYHttpManagerDelegate <NSObject>

//- (void)postSuccessToRequest:(LAndRRequest* )manager withData:(id)data;
@optional
//成功了
- (void)successToRequest:(LAndRRequest* )manager withData:(id)data;

//失败了
- (void)failToRequest:(LAndRRequest* )manager withData:(id)data;

@end

//负责发送请求的

@interface LAndRRequest : NSObject
{
    
}
@property(nonatomic,assign)id<ZYHttpManagerDelegate> delegate;
@property(nonatomic,assign)NSInteger tag;

//封装常用的方法（get和post请求）

//1.get请求方法

- (void)startGetConnectionWithPath:(NSString *)path parameter:(NSDictionary *)parameter;

//2.post请求方式

- (void)startPostConnectionWithPath:(NSString *)path parameter:(NSDictionary *)parameter;



@end
