//
//  ViewController.h
//  https
//
//  Created by 涛程 on 16/3/24.
//  Copyright © 2016年 涛程. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LAndRRequest.h"
#import <JavaScriptCore/JavaScriptCore.h>
@interface ViewController : UIViewController<UIWebViewDelegate,ZYHttpManagerDelegate>

@property (nonatomic,weak) JSContext * context;
@property (nonatomic ,retain)LAndRRequest *manager;
@property(nonatomic,retain)NSMutableDictionary *messageDic;
@end

