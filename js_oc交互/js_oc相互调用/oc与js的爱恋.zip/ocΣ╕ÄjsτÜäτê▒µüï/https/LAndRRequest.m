//
//  LAndRRequest.m
//  XFDNavTest
//
//  Created by lwk on 15/11/30.
//  Copyright © 2015年 lwk. All rights reserved.
//

#import "LAndRRequest.h"


@implementation LAndRRequest
- (void)startGetConnectionWithPath:(NSString *)path parameter:(NSDictionary *)parameter
{
    path=[path stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableString *absoluteString = [[NSMutableString alloc] initWithFormat:@"https://github.com%@",path];
    //判断是否需要传参
    if([parameter count]>0){
        //用来保存遍历出来的参数
        NSMutableArray *query = [[NSMutableArray alloc] init];
        //枚举出字典中的key 和 值
        [parameter enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            
            NSString *parameterString = [[NSString alloc] initWithFormat:@"%@=%@",key,obj];
            
            [query addObject:parameterString];
            
        }];
        //拼接参数到url后面 ？ &

        [absoluteString appendFormat:@"?%@",[query componentsJoinedByString:@"&"]];
//        
    }
    NSString *str=absoluteString;
    str=[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"请求地址：%@",str);

    // 初始化Manager
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    // 不加上这句话，会报“Request failed: unacceptable content-type: text/plain”错误，因为我们要获取text/plain类型数据
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    
    // Get请求
    [manager GET:str parameters:parameter progress:^(NSProgress * _Nonnull downloadProgress) {
        // 这里可以获取到目前的数据请求的进度
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        // 请求成功，解析数据
        NSLog(@"%@", responseObject);
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers | NSJSONReadingMutableLeaves error:nil];
        
        NSLog(@"%@", dic);
        
        [self.delegate successToRequest:self withData:responseObject];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        // 请求失败
        NSLog(@"%@", [error localizedDescription]);
    }];

}

- (void)startPostConnectionWithPath:(NSString *)path parameter:(NSDictionary *)parameter
{
    path=[path stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableString *absoluteString = [[NSMutableString alloc] initWithFormat:@"https://github.com%@",path];
    
    NSString *str=absoluteString;
    str=[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"请求地址：%@",str);
    
    
    // 初始化Manager
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    // 不加上这句话，会报“Request failed: unacceptable content-type: text/plain”错误，因为我们要获取text/plain类型数据
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    

    // post请求
    [manager POST:str parameters:parameter constructingBodyWithBlock:^(id  _Nonnull formData) {
        // 拼接data到请求体，这个block的参数是遵守AFMultipartFormData协议的。
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        // 这里可以获取到目前的数据请求的进度
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        // 请求成功，解析数据
        NSLog(@"66666666==%@", responseObject);
//        NSData *doubi = responseObject;
//        NSString *shabi =  [[NSString alloc]initWithData:doubi encoding:NSUTF8StringEncoding];
//        NSLog(@"Success  utf8:%@",shabi);
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers | NSJSONReadingMutableLeaves error:nil];
        NSLog(@"7777777777==%@", dic);
        
        [self.delegate successToRequest:self withData:responseObject];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        // 请求失败
        NSLog(@"%@", [error localizedDescription]);
    }];
    
}


@end
